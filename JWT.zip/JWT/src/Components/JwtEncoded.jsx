import React, { useState } from 'react';

const JwtEncoded = ({ onEncode }) => {
  const [encodedText, setEncodedText] = useState('');

  const handleChange = (event) => {
    setEncodedText(event.target.value);
  };

  const handleSubmit = async () => {
    try {
      await onEncode(encodedText); // Call the provided onEncode
      alert('Text encoded successfully!');
    } catch (error) {
      alert('Failed to encode text. Please try again.');
    }
  };

  return (
    <div>
      <h2>JWT Encoded</h2>
      <textarea
        value={encodedText}
        onChange={handleChange}
        placeholder="Enter text to encode"
        rows={6} 
        className="form-control mb-3"
      />
      <div className="mb-3">
        <button onClick={handleSubmit} className="btn btn-success btn-lg">Encode</button>
      </div>
    </div>
  );
};

export default JwtEncoded;
