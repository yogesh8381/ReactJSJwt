import React, { useState } from 'react';
import Navigationbar from './Navigationbar';
import Footer from './Footer';
import JwtEncoded from './JwtEncoded';
import JwtDecoded from './JwtDecoded';
import { getAllPosts } from './api'; 

const HomePage = () => {
  const [decodedText, setDecodedText] = useState('');
  const [loading, setLoading] = useState(false); 
  const [error, setError] = useState(null); 


  const handleEncode = async (text) => {
    try {
      setLoading(true); 
      const response = await getAllPosts(text); 
      const encodedText = response.title; 
      setDecodedText(encodedText); 
      setLoading(false);
    } catch (error) {
      setLoading(false); 
      setError(error.message || 'An error occurred'); 
    }
  };

  return (
    <div>
      <Navigationbar />
      <div className="container mt-5">
        <div className="row">
          <div className="col-md-6">
          
            <JwtEncoded onEncode={handleEncode} />
          </div>
          <div className="col-md-6">
            
            <JwtDecoded decodedText={decodedText} loading={loading} error={error} />
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default HomePage;
