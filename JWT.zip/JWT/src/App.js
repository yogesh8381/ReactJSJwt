import React from 'react';
import './App.css';
import Navigationbar from './Components/Navigationbar';
import HomePage from './Components/HomePage';


function App() {
  return (
    <div className="App">
      <HomePage/>
    </div>
  );
}

export default App;
