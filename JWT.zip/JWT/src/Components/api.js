// api.js
import axios from 'axios';

const BASE_URL = 'https://jsonplaceholder.typicode.com'; // Sample URL for dummy data

const api = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Modify the function to accept a text parameter
export const getAllPosts = async (text) => {
  try {
    const response = await api.get('/posts/1', { params: { text } }); // Pass text as query parameter
    return response.data;
  } catch (error) {
    console.error('Error fetching posts:', error);
    throw error;
  }
};
