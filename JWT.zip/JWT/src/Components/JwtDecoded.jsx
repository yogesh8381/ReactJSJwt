
import React, { useState } from 'react';

const JwtDecoded = ({ decodedText }) => {
  return (
    <div>
      <h2>JWT Decoded</h2>
      <textarea
        value={decodedText}
        placeholder="Decoded JSON data will be displayed here"
        rows={6} // Adjust the number of rows as needed
        className="form-control"
        readOnly
      />
    </div>
  );
};

export default JwtDecoded;